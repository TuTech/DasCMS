<?php
//wechseln zum bambus root-verzeichnis
chdir('..');
require_once('./System/Component/Loader.php');
header('Content-Type: text/html; charset=utf-8');

//wenn login nicht per form sondern nach .htaccess art übergeben werden sollen:
//RSent::alter("bambus_cms_username", $_SERVER['PHP_AUTH_USER']);
//RSent::alter("bambus_cms_password", $_SERVER['PHP_AUTH_PW']);

//login daten prüfen (user "bambus_cms_username", passwort "bambus_cms_password" aus session/post)
PAuthentication::required();

if(
    PAuthorisation::has('org.bambus-cms.login') && //alte cms login gruppe
    PAuthorisation::has('de.p-ad.eurift.edit')//passt auf alte edit gruppe
    ) //login ok?
{
    //...
}
else
{
    //login form
    	//text-input "bambus_cms_username"
		//password-input "bambus_cms_password"
	//oder 401 header
}
?>